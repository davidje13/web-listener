import { requestHandler } from 'web-listener';

export default requestHandler((_, res) => res.end('bundled custom response'));
